package ticTacToeGame;

/**
 * Main class of the Java program.
 */

public class Main {

    public static void main(String[] args) {
        System.out.println("Tic Tac Toe ");
        TTT game = new TTT();
        game.play();
    }
}
